# TermiChat - Linux Distribution

## Installation

1. Extract this archive to your desired location
2. Open Terminal
3. Navigate to the extracted directory
4. Run the commands below

## Usage

### Start Server
```bash
./termichat-server --port 8000
```

### Connect Client
```bash
./termichat-client --port 8000 --user-id yourname
```

### With TLS Encryption
```bash
# Generate certificates
./termichat-generate-certs

# Start server with TLS
./termichat-server --auto-cert --port 8443

# Connect client with TLS
./termichat-client --tls --insecure --port 8443 --user-id yourname
```

### Multiple Clients
```bash
# Terminal 1: Server
./termichat-server --port 8000

# Terminal 2: Client 1
./termichat-client --port 8000 --user-id alice

# Terminal 3: Client 2
./termichat-client --port 8000 --user-id bob
```

## Commands (after connecting)

- `/to <user_id>` - Set message recipient
- `/broadcast <message>` - Send message to all users
- `/users` - List connected users
- `/help` - Show help
- `/quit` - Exit

## Security Features

- ✅ TLS/SSL encryption
- ✅ Message encryption (AES-256-GCM)
- ✅ Input validation and sanitization
- ✅ Rate limiting protection
- ✅ Certificate generation

## System Requirements

- Linux x64 (Ubuntu, Debian, CentOS, etc.)
- No additional dependencies required

## Support

For issues and questions, please visit the project repository. 