# TermiChat - Windows Distribution

## Installation

1. Extract this archive to your desired location
2. Open Command Prompt or PowerShell
3. Navigate to the extracted directory
4. Run the commands below

## Usage

### Start Server
```cmd
termichat-server.exe --port 8000
```

### Connect Client
```cmd
termichat-client.exe --port 8000 --user-id yourname
```

### With TLS Encryption
```cmd
# Generate certificates
termichat-generate-certs.exe

# Start server with TLS
termichat-server.exe --auto-cert --port 8443

# Connect client with TLS
termichat-client.exe --tls --insecure --port 8443 --user-id yourname
```

### Multiple Clients
```cmd
# Command Prompt 1: Server
termichat-server.exe --port 8000

# Command Prompt 2: Client 1
termichat-client.exe --port 8000 --user-id alice

# Command Prompt 3: Client 2
termichat-client.exe --port 8000 --user-id bob
```

## Commands (after connecting)

- `/to <user_id>` - Set message recipient
- `/broadcast <message>` - Send message to all users
- `/users` - List connected users
- `/help` - Show help
- `/quit` - Exit

## Security Features

- ✅ TLS/SSL encryption
- ✅ Message encryption (AES-256-GCM)
- ✅ Input validation and sanitization
- ✅ Rate limiting protection
- ✅ Certificate generation

## System Requirements

- Windows 10 or later (x64)
- No additional dependencies required

## Troubleshooting

### Permission Issues
If you get permission errors, try running Command Prompt as Administrator.

### Firewall Issues
Windows Firewall may block the connection. Allow the application when prompted.

### Antivirus Warnings
Some antivirus software may flag the executables. This is normal for compiled applications. You can add an exception if needed.

## Support

For issues and questions, please visit the project repository. 