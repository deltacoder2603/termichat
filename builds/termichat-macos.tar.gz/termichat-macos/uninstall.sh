#!/bin/bash

echo "🗑️ Uninstalling TermiChat..."

# Remove binaries
sudo rm -f /usr/local/bin/termichat-server
sudo rm -f /usr/local/bin/termichat-client
sudo rm -f /usr/local/bin/termichat-generate-certs

echo "✅ TermiChat uninstalled successfully!"
