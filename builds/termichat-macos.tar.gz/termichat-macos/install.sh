#!/bin/bash

echo "🍎 Installing TermiChat..."

# Create installation directory
INSTALL_DIR="/usr/local/bin"
sudo mkdir -p "${INSTALL_DIR}"

# Copy binaries
sudo cp termichat-server "${INSTALL_DIR}/"
sudo cp termichat-client "${INSTALL_DIR}/"
sudo cp termichat-generate-certs "${INSTALL_DIR}/"

# Make executable
sudo chmod +x "${INSTALL_DIR}/termichat-server"
sudo chmod +x "${INSTALL_DIR}/termichat-client"
sudo chmod +x "${INSTALL_DIR}/termichat-generate-certs"

echo "✅ TermiChat installed successfully!"
echo ""
echo "🚀 Usage:"
echo "  termichat-server --port 8000"
echo "  termichat-client --port 8000 --user-id yourname"
echo ""
echo "📖 For more help:"
echo "  termichat-server --help"
echo "  termichat-client --help"
